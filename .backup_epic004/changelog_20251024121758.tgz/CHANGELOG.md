2025-10-16 — Repo docs consolidation (SoT + HTTP home)
• SoT clarified: Public body & determinism → “HD Engine — Math & Technical Spec”; Transport/caching acceptance → “Governance & Process (Acceptance)”.
• HTTP home: canonical adapter at adapter/http_reader.py; dev runner at dev/reader_harness/app.py (APP_ENV=dev). server/ is legacy (kept temporarily).
• Removed restatements of A7 tables from repo docs; link to Governance instead.
• Embedded evidence pointers in notes: tests/test_emitter_determinism.py, tests/test_reader_transport.py, tests/cli/*.

CHANGELOG

2025-10-02 — A7 alignment and contract centralization (v2.0 / v0.1.5)

[Env & Integration] Environment & Integration Plan v2.0

Canonical home for HTTP transport (A7): strong quoted ETag = sha256(final LF-terminated public bytes, pre-compression), Cache-Control: private, max-age=0, must-revalidate, Vary: Authorization, Accept-Encoding.

Conditional GET: CSV If-None-Match, weak tags ignored, strong compare only. 304 returns empty body; validators preserved; Content-Length: 0 or absent; Content-Type optional.

HEAD parity: validators identical to GET 200; no body; Content-Length == len(identity body).

Compression invariance: same ETag for identity, gzip, br.

Writers and errors: no ETag, Cache-Control: no-store.

Non-negotiables summarized: canonical serializer, idempotence preimage, single emitter, SAFE rails, security headers, logging and correlation.


[Reader] docs/server/reader_v1.md v2.0

Dev harness surface reaffirmed and gated to APP_ENV=dev; path policy under fixtures/charts/ with traversal and symlink denial.

Transport section links to Env v2.0; examples and acceptance markers added.

Bytes returned by Reader remain identical to CLI for the same inputs; one trailing LF.


[Contract] docs/contracts/reader_v1_public_bytes.md v1.0 (new)

Single canonical public body example (minified, sorted keys, UTF-8, one trailing LF).

Allowed enums and closed public set for Alpha: categories[0] = {"id":"harmony","band":"Cool|Open|Warm|Glow"}.

Idempotence preimage rule and a worked ETag over the final bytes.

De-duplicates schema examples across repo docs.


[Spec] Glow HD Engine — CLI, API & Vendor Ingest Spec v0.1.5

Front matter bumped; supersession map added: transport → Env v2.0, public body → Contract, Reader surface → reader_v1.md.

§2.1/2.2 tightened (serializer and regexes, including correlation id); §2.4 public categories clarified; §2.5 numeric policy clarified (Reader numeric-free; CLI --score gated).

§3.1 retitled to Idempotence (hash preimage); transport specifics moved to Env v2.0.

§18 acceptance updated to point to Env v2.0 for transport; markers kept prose-only.


[CLI] docs/CLI_commands.md v2.0

Purpose and scope clarified; stdout contract pinned (bands-only by default).

Numeric policy: top-level score_pct only with --score; half-up to 2dp; does not affect any other bytes.

Idempotence preimage coupling and strict sidecar gate restated; exit codes and acceptance evidence names listed.


[Emitters] docs/architecture/emitters.md v2.0

Single-emitter canon: CLI and Reader must import the same public emitter.

Serializer and idempotence rules centralized; AB↔BA and two-run identity required.

Provenance evidence names listed; no commands embedded.


[Alpha Acceptance] docs/alpha_acceptance.md v1.4

A3 and A5 acceptance tightened with evidence paths and PASS marker names.

Notes that A7 transport acceptance lives in Env v2.0; not restated here.


[Governance] Glow Governance & Process Handbook v1.1

Human/AI disclosure and access model restated: one human with agency; AI access via bundles only.

Source-of-truth map added; acceptance delivery policy (one revert-friendly commit with evidence) affirmed.


[Engine Tasks] HD Engine Tasks v10

Tracks updated to align with A7 and current canon.

F2: ETag and 304 discipline spelled out with Do and Accept.

I2: Rate limits clarified (Reader 120/480; Aux 30/120; 429 with Retry-After delta seconds or HTTP-date); evidence expectations listed.

Sources-of-truth pointers added to avoid duplicating transport or public body rules.


[Acceptance crib] docs/acceptance/reader_a7_crib.md (new)

One-page, command-free acceptance checklist names and artifact expectations for A7 transport, suitable for FE and QA rehearsals.



---

2025-10-01 — Alpha docs/playbooks refresh (v1.2)

(unchanged from prior; retained here for history) 

[A3] CLI Alpha Public Invariant (docs/CLI_commands.md v1.2)

Public stdout pinned to canonical key set and order: ["categories","eligible","idempotence_hash","meta","release_id"] (sorted-keys JSON), one trailing LF, BOM-free, ANSI-free.

Categories rule clarified: single element with only {"id":"harmony","band":"Cool|Open|Warm|Glow"}.

Idempotence preimage rule affirmed (lowercase sha256 over canonical preimage).

Sidecar gate hardened: requires --showmath AND --admin-out AND (--admin OR HD_ADMIN=1); negative gate → exit 2, stdout empty, no file; positive gate → atomic, 0600, LF.

TS-v0 in A3/A5 remains minimal (no admin numerics).

Determinism: AB↔BA parity and two-run identity required.

Minimal artifacts standardized: cli_stdout_AB.json, cli_stdout_BA.json, release_id.txt, IDENTITY_OK.txt, validation.log (sidecar only if gate exercised).

Release identity discipline: scripts/release_id.sh prints a single 64-hex + LF (no args, no extra text).


[A5] Reader v1 Minimal API (docs/server/reader_v1.md v1.2)

Dev harness only: APP_ENV!=dev → 403 with {"error":"forbidden"}\n, no filesystem access.

Path policy: relative a/b resolved under fixtures/charts/; reject absolute paths, traversal, symlinks.

Transport: Content-Type: application/json; charset=utf-8 for success and errors; no ETag/Cache-Control, no 304 (A6 will add).

Public bytes equal CLI bytes for AB and BA; optional two-run identity.

Error bodies: single-line JSON + LF with tokens invalid_path|invalid_json|missing_tz_A|missing_tz_B.

Provenance: record EMITTER_SHA256=<64hex> for engine/emit_public.py.

Minimal artifacts standardized: reader_AB.json, reader_BA.json, headers_AB.txt, headers_BA.txt, validation.log.


[Emitters] Single Emitter Canon (docs/architecture/emitters.md v1.2)

Canonical module engine/emit_public.py required by both CLI and Reader.

Public envelope keys/order and preimage rule pinned; AB↔BA parity required.

Purity rules: no import-time I/O, no network, no file writes; keys-only logs.

Evidence: record EMITTER_SHA256 in A5 validation log.


[Alpha Acceptance] Consolidated Gate (docs/alpha_acceptance.md v1.2)

Aggregates A3/A5 invariants, minimal artifacts, and minimal validation markers.

Governance restated: single revert-friendly commit to main with evidence under artifacts/cards/<CARD>/; no PRs for final approval.

SAFE rails: acceptance runs with SAFE_MODE=1; network only if both SAFE_MODE=0 and ALLOW_NETWORK=1 are set.



---

Operator note
Repo docs are implementation playbooks. Canonical project documents (Environment & Integration Plan, Governance/Process, Engine Math/TS-v0, Spec) carry the authoritative rules and links.

