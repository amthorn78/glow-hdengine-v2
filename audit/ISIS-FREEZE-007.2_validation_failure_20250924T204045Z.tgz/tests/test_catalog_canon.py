import json, pathlib
def _walk_objects(s, found):
    if isinstance(s, dict):
        if s.get("type") == "object":
            found.append(s)
        for v in s.values():
            _walk_objects(v, found)
    elif isinstance(s, list):
        for v in s:
            _walk_objects(v, found)

def _all_objects_are_strict(schema_dict):
    objs=[]; _walk_objects(schema_dict, objs)
    return all(obj.get("additionalProperties", False) is False for obj in objs)

def test_schema_accepts_valid_rejects_unknown():
    gates = json.loads(pathlib.Path("schemas/gates_v1.schema.json").read_text(encoding="utf-8"))
    chans = json.loads(pathlib.Path("schemas/channels_v1.schema.json").read_text(encoding="utf-8"))
    assert _all_objects_are_strict(gates)
    assert _all_objects_are_strict(chans)
    # spot-check critical constraints exist
    assert "gates" in gates["properties"]
    assert "channels" in chans["properties"]
    # id regex, closed enums present
    id_pat = chans["properties"]["channels"]["items"]["properties"]["id"]["pattern"]
    assert id_pat == r"^\d{2}-\d{2}$"
    flags_enum = chans["properties"]["channels"]["items"]["properties"]["flags"]["items"]["enum"]
    assert flags_enum == ["format","direct_mt"]
