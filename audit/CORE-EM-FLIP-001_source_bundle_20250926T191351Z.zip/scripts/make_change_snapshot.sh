#!/usr/bin/env bash
set -euo pipefail

CARD="${1:-CARD-UNSPECIFIED}"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"; cd "$ROOT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTDIR="audit"; mkdir -p "$OUTDIR"
SNAP_DIR="${OUTDIR}/${CARD}_snapshot_${STAMP}"
MANIFEST="${OUTDIR}/${CARD}_snapshot_manifest_${STAMP}.json"
PATCH="${OUTDIR}/${CARD}_diff_${STAMP}.patch"
LIST="${OUTDIR}/${CARD}_changed_${STAMP}.txt"

# 1) Collect changed paths vs HEAD (M/A/R/D) + untracked
#    We keep deleted in the manifest (cannot copy), copy everything else except *.zip.
git diff --name-status -z HEAD > /tmp/_chg_z.txt || true
git ls-files --others --exclude-standard -z >> /tmp/_untracked_z.txt || true

# Parse to line/fields
python3 - <<'PY' >/tmp/_changed.json
import sys, json, os
def parse_z_status(p):
    data = sys.stdin.buffer.read().split(b'\x00')
    it = iter(data)
    out=[]
    for rec in it:
        if not rec: continue
        # rec may be like "M\tpath" or "A\tpath" or "R100\told\tnew"
        parts = rec.decode('utf-8', 'replace').split('\t')
        if parts[0].startswith('R'):  # rename
            try:
                oldp = next(it).decode('utf-8','replace'); newp = next(it).decode('utf-8','replace')
            except StopIteration:
                continue
            out.append({"status":"R", "path": newp, "old": oldp})
        else:
            status = parts[0][:1]
            path = parts[1] if len(parts)>1 else ''
            out.append({"status":status, "path": path})
    return out

changed = []
# HEAD diff
try:
    with open("/tmp/_chg_z.txt","rb") as f:
        sys.stdin = f; changed.extend(parse_z_status(sys.stdin))
except FileNotFoundError:
    pass

# Untracked
try:
    with open("/tmp/_untracked_z.txt","rb") as f:
        data = f.read().split(b'\x00')
        for p in data:
            if not p: continue
            changed.append({"status":"U", "path": p.decode('utf-8','replace')})
except FileNotFoundError:
    pass

# Deduplicate, keep last status
seen={}
for item in changed:
    seen[item["path"]] = item

print(json.dumps({"changed": list(seen.values())}))
PY

jq -r '.changed[].path' /tmp/_changed.json 2>/dev/null | LC_ALL=C sort -u > "$LIST" || echo -n > "$LIST"

# 2) Snapshot copy (exclude *.zip). Keep directory structure under SNAP_DIR.
mkdir -p "$SNAP_DIR"
while IFS= read -r rel; do
  [[ -z "$rel" ]] && continue
  [[ ! -e "$rel" ]] && continue               # skip deleted files
  [[ "$rel" == *.zip ]] && continue           # exclude zip files
  destdir="${SNAP_DIR}/$(dirname "$rel")"
  mkdir -p "$destdir"
  # Preserve mode/time; copy file content
  cp -p "$rel" "${SNAP_DIR}/$rel"
done < "$LIST"

# 3) Create a binary-safe diff patch vs HEAD for reference
git diff --binary HEAD > "$PATCH" || true

# 4) Build manifest with sha256, size, status (for existing files); include deletions.
python3 - <<'PY' > "$MANIFEST"
import json, os, hashlib, sys
with open("/tmp/_changed.json","r",encoding="utf-8") as f:
    changed = {e["path"]: e for e in json.load(f)["changed"]}
def sha256_of(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()
entries=[]
for rel, meta in changed.items():
    entry={"path": rel, "status": meta["status"]}
    if os.path.exists(rel) and not rel.endswith(".zip"):
        try:
            entry["size"] = os.path.getsize(rel)
            entry["sha256"] = sha256_of(rel)
        except Exception as e:
            entry["error"] = f"{type(e).__name__}: {e}"
    else:
        entry["size"] = None
        entry["sha256"] = None
    entries.append(entry)
print(json.dumps({
    "card": os.environ.get("CARD_ID",""),
    "base": "HEAD",
    "count": len(entries),
    "files": entries
}, ensure_ascii=False, indent=2))
PY

# 5) Announce artifacts (machine-readable markers)
echo "[snapshot_dir] $SNAP_DIR"
echo "[snapshot_manifest] $MANIFEST"
echo "[snapshot_list] $LIST"
echo "[snapshot_diff] $PATCH"
