#!/usr/bin/env bash
set -euo pipefail

JSON_ONLY=0
if [[ "${1-}" == "--json" ]]; then
  JSON_ONLY=1
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"

# Run Python with JSON_ONLY env set so stdout is ONLY the JSON body when requested
JSON_ONLY="${JSON_ONLY}" "$PYTHON_BIN" - <<'PY'
import sys, json, pathlib, os, hashlib

# Ensure repo root on path
sys.path.insert(0, str(pathlib.Path('.').resolve()))

from core.canon.validate import load_repo_canon
from core.canon.checksums import build_checksums
from core.stable import sercanon  # stable serializer

ROOT = pathlib.Path('.')
ART = ROOT / 'artifacts'
ART.mkdir(parents=True, exist_ok=True)

checksums_path = ROOT / 'CANON_CHECKSUMS.json'
report_path    = ART  / 'canon_report.json'

def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def _to_text(s) -> str:
    if isinstance(s, (bytes, bytearray)):
        return s.decode('utf-8')
    return str(s)

def _canon_bytes(obj) -> bytes:
    # canonical string (no newline), then add single LF
    s = _to_text(sercanon.stable_dumps(obj))
    if s.endswith("\n"):
        s = s.rstrip("\n")
    return (s + "\n").encode("utf-8")

def _write_one(path: pathlib.Path, obj) -> bytes:
    b = _canon_bytes(obj)
    path.write_bytes(b)
    # serializer guard: re-serialize the object again and compare bytes
    guard_b = _canon_bytes(obj)
    if guard_b != b:
        sys.stderr.write("CANON_SERIALIZER_MISMATCH\n")
        sys.exit(23)
    return b

def _two_run_identity(path: pathlib.Path, obj):
    b1 = _write_one(path, obj)
    b2 = _write_one(path, obj)
    if _sha(b1) != _sha(b2):
        sys.stderr.write("CANON_IDENTITY_MISMATCH: " + path.name + "\n")
        sys.exit(24)
    return _sha(b1)

# Load canon from repo files
canon = load_repo_canon(ROOT)

# Build checksums + report (compact, deterministic)
chs = build_checksums(canon)

def _count(seq):
    if isinstance(seq, list): return len(seq)
    if isinstance(seq, dict):
        if "gates" in seq and isinstance(seq["gates"], list): return len(seq["gates"])
        if "channels" in seq and isinstance(seq["channels"], list): return len(seq["channels"])
        return len(seq)
    return 0

report = {
    "ok": True,
    "schema": "v1",
    "summary": {
        "gates": _count(canon.get("gates")),
        "channels": _count(canon.get("channels")),
    },
    "hashes": {}
}

# Write artifacts twice; ensure byte identity
chs_sha = _two_run_identity(checksums_path, chs)
rep_sha = _two_run_identity(report_path, report)
report["hashes"] = {"checksums_sha256": chs_sha, "report_sha256": rep_sha}

# If requested, print ONLY the JSON body (newline-terminated)
if os.environ.get("JSON_ONLY") == "1":
    sys.stdout.write(_to_text(sercanon.stable_dumps(report)) + "\n")
PY
