import json, re, subprocess, sys, pathlib, hashlib
from core.canon.validate import load_repo_canon
from core.canon.checksums import build_checksums
from core.stable import sercanon

HEX64 = re.compile(r"^[0-9a-f]{64}$")

def test_report_and_checksums_determinism(tmp_path):
    canon = load_repo_canon(pathlib.Path("."))
    ch1 = build_checksums(canon)
    ch2 = build_checksums(canon)
    b1 = (sercanon.stable_dumps(ch1) + "\n").encode("utf-8")
    b2 = (sercanon.stable_dumps(ch2) + "\n").encode("utf-8")
    h1 = hashlib.sha256(b1).hexdigest()
    h2 = hashlib.sha256(b2).hexdigest()
    assert b1 == b2 and h1 == h2

def test_validate_script_json_output():
    # --json must print exactly one JSON object (newline-terminated) with expected keys/patterns
    out = subprocess.check_output(["bash", "scripts/validate_canon.sh", "--json"], text=True)
    # Must end with a single newline
    assert out.endswith("\n")
    # The body should be a single JSON object
    doc = json.loads(out)
    assert doc.get("ok") is True and doc.get("schema") == "v1"
    hashes = doc.get("hashes", {})
    assert HEX64.match(hashes.get("checksums_sha256", "")) and HEX64.match(hashes.get("report_sha256", ""))
